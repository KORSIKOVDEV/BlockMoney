<?php

namespace BlockMoney;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\block\Block;
use pocketmine\item\Item;
use onebone\economyapi\EconomyAPI;
use pocketmine\Server;

class BlockMoney extends PluginBase implements Listener{
   public function onEnable(){
   	$this->getLogger()->info("»-------*+*-------«");
       $this->getLogger()->info("» Создатель плагина -» VK.COM/KORSIKOV_DEV");
       $this->getLogger()->info("» ТОП ПЛАГИНЫ -» VK.COM/SPLUGIN_DEVELOPED");
       $this->getLogger()->info("»-------*+*-------«");
     $this->getServer()->getPluginManager()->registerEvents($this, $this);
     $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
   }
   
   public function onBreak(BlockBreakEvent $e){
     $p = $e->getPlayer();
     $block = $e->getBlock();
     $random = mt_rand(1, 5);
       if($block->getId() == 1 or $block->getId() == 7 or $block->getId() == 8 or $block->getId() == 9 or $block->getId() == 10){
       $p->sendPopup("Ты получил§b $random §fмонет, за то что сломал редкий блок");
       EconomyAPI::getInstance()->addMoney($p, $random);
        }
    }
}